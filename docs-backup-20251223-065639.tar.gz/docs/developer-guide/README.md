# Developer Guide

Welcome to the KOSMOS Developer Guide. This section provides all the resources you need to start building on the KOSMOS platform.
