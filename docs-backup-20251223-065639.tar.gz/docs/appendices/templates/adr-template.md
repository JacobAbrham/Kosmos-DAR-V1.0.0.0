# ADR-XXX: [Title]

**Status:** Proposed | Accepted | Deprecated  
**Date:** YYYY-MM-DD  
**Decision Makers:** [Names]  

## Context
[Describe the problem and context]

## Decision
[State the decision made]

## Consequences
[List positive and negative consequences]

## Alternatives Considered
[Document alternatives that were rejected]

---

See [ADR Template](../../02-architecture/adr/template.md) for full template.
